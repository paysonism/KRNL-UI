﻿
namespace Sexploit_Y
{
    partial class krnlss
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(krnlss));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listbox1 = new System.Windows.Forms.TreeView();
            this.ExecuteBox = new FastColoredTextBoxNS.FastColoredTextBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.injectToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.killRobloxToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.creditsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.joinDiscordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gitHubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.websiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.siticoneDragControl1 = new Siticone.UI.WinForms.SiticoneDragControl(this.components);
            this.siticoneDragControl2 = new Siticone.UI.WinForms.SiticoneDragControl(this.components);
            this.Executebtn = new ns1.BunifuFlatButton();
            this.Clearbtn = new ns1.BunifuFlatButton();
            this.Openbtn = new ns1.BunifuFlatButton();
            this.Savebtn = new ns1.BunifuFlatButton();
            this.Injectbtn = new ns1.BunifuFlatButton();
            this.OptionsBtn = new ns1.BunifuFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ExecuteBox)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.panel2.Location = new System.Drawing.Point(249, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(443, 25);
            this.panel2.TabIndex = 27;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel3.Location = new System.Drawing.Point(-9, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(700, 3);
            this.panel3.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(610, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 33);
            this.button2.TabIndex = 4;
            this.button2.Text = "_";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(647, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 33);
            this.button1.TabIndex = 3;
            this.button1.Text = "✕";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(25, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(679, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "KRNL";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(679, 33);
            this.panel1.TabIndex = 26;
            // 
            // listbox1
            // 
            this.listbox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listbox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.listbox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listbox1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbox1.ForeColor = System.Drawing.Color.White;
            this.listbox1.HideSelection = false;
            this.listbox1.LineColor = System.Drawing.Color.White;
            this.listbox1.Location = new System.Drawing.Point(566, 60);
            this.listbox1.Name = "listbox1";
            this.listbox1.Size = new System.Drawing.Size(109, 251);
            this.listbox1.TabIndex = 25;
            this.listbox1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.listbox1_SelectedIndexChanged);
            // 
            // ExecuteBox
            // 
            this.ExecuteBox.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.ExecuteBox.AutoIndentCharsPatterns = "\r\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>.+)\r\n";
            this.ExecuteBox.AutoScrollMinSize = new System.Drawing.Size(0, 224);
            this.ExecuteBox.BackBrush = null;
            this.ExecuteBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.ExecuteBox.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.ExecuteBox.CaretColor = System.Drawing.Color.White;
            this.ExecuteBox.CharHeight = 14;
            this.ExecuteBox.CharWidth = 8;
            this.ExecuteBox.CommentPrefix = "--";
            this.ExecuteBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ExecuteBox.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.ExecuteBox.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.ExecuteBox.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ExecuteBox.IndentBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.ExecuteBox.IsReplaceMode = false;
            this.ExecuteBox.Language = FastColoredTextBoxNS.Language.Lua;
            this.ExecuteBox.LeftBracket = '(';
            this.ExecuteBox.LeftBracket2 = '{';
            this.ExecuteBox.LineNumberColor = System.Drawing.Color.White;
            this.ExecuteBox.Location = new System.Drawing.Point(5, 60);
            this.ExecuteBox.Name = "ExecuteBox";
            this.ExecuteBox.Paddings = new System.Windows.Forms.Padding(0);
            this.ExecuteBox.RightBracket = ')';
            this.ExecuteBox.RightBracket2 = '}';
            this.ExecuteBox.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.ExecuteBox.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("ExecuteBox.ServiceColors")));
            this.ExecuteBox.ServiceLinesColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.ExecuteBox.Size = new System.Drawing.Size(555, 251);
            this.ExecuteBox.TabIndex = 34;
            this.ExecuteBox.Text = resources.GetString("ExecuteBox.Text");
            this.ExecuteBox.TextAreaBorderColor = System.Drawing.Color.Transparent;
            this.ExecuteBox.WordWrap = true;
            this.ExecuteBox.Zoom = 100;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.menuStrip2.AutoSize = false;
            this.menuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.creditsToolStripMenuItem,
            this.creditsToolStripMenuItem1,
            this.othersToolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 32);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(270, 24);
            this.menuStrip2.TabIndex = 35;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.injectToolStripMenuItem1,
            this.killRobloxToolStripMenuItem1});
            this.fileToolStripMenuItem1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // injectToolStripMenuItem1
            // 
            this.injectToolStripMenuItem1.Name = "injectToolStripMenuItem1";
            this.injectToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.injectToolStripMenuItem1.Text = "Inject";
            this.injectToolStripMenuItem1.Click += new System.EventHandler(this.injectToolStripMenuItem1_Click);
            // 
            // killRobloxToolStripMenuItem1
            // 
            this.killRobloxToolStripMenuItem1.Name = "killRobloxToolStripMenuItem1";
            this.killRobloxToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.killRobloxToolStripMenuItem1.Text = "Kill Roblox";
            this.killRobloxToolStripMenuItem1.Click += new System.EventHandler(this.killRobloxToolStripMenuItem1_Click);
            // 
            // creditsToolStripMenuItem
            // 
            this.creditsToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.creditsToolStripMenuItem.Name = "creditsToolStripMenuItem";
            this.creditsToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.creditsToolStripMenuItem.Text = "Credits";
            this.creditsToolStripMenuItem.Click += new System.EventHandler(this.creditsToolStripMenuItem_Click);
            // 
            // creditsToolStripMenuItem1
            // 
            this.creditsToolStripMenuItem1.AccessibleName = "scripthubtoolStripMenuItem1";
            this.creditsToolStripMenuItem1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.creditsToolStripMenuItem1.Name = "creditsToolStripMenuItem1";
            this.creditsToolStripMenuItem1.Size = new System.Drawing.Size(75, 20);
            this.creditsToolStripMenuItem1.Text = "Script Hub";
            this.creditsToolStripMenuItem1.Click += new System.EventHandler(this.creditsToolStripMenuItem1_Click);
            // 
            // othersToolStripMenuItem1
            // 
            this.othersToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.joinDiscordToolStripMenuItem,
            this.gitHubToolStripMenuItem,
            this.websiteToolStripMenuItem});
            this.othersToolStripMenuItem1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.othersToolStripMenuItem1.Name = "othersToolStripMenuItem1";
            this.othersToolStripMenuItem1.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem1.Text = "Others";
            // 
            // joinDiscordToolStripMenuItem
            // 
            this.joinDiscordToolStripMenuItem.Name = "joinDiscordToolStripMenuItem";
            this.joinDiscordToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.joinDiscordToolStripMenuItem.Text = "Join Discord";
            this.joinDiscordToolStripMenuItem.Click += new System.EventHandler(this.joinDiscordToolStripMenuItem_Click);
            // 
            // gitHubToolStripMenuItem
            // 
            this.gitHubToolStripMenuItem.Name = "gitHubToolStripMenuItem";
            this.gitHubToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.gitHubToolStripMenuItem.Text = "GitHub";
            this.gitHubToolStripMenuItem.Click += new System.EventHandler(this.gitHubToolStripMenuItem_Click);
            // 
            // websiteToolStripMenuItem
            // 
            this.websiteToolStripMenuItem.Name = "websiteToolStripMenuItem";
            this.websiteToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.websiteToolStripMenuItem.Text = "Website";
            this.websiteToolStripMenuItem.Click += new System.EventHandler(this.websiteToolStripMenuItem_Click);
            // 
            // siticoneDragControl1
            // 
            this.siticoneDragControl1.TargetControl = this.panel1;
            // 
            // siticoneDragControl2
            // 
            this.siticoneDragControl2.TargetControl = this.label1;
            // 
            // Executebtn
            // 
            this.Executebtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.Executebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Executebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Executebtn.BorderRadius = 0;
            this.Executebtn.ButtonText = "EXECUTE";
            this.Executebtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.Executebtn.DisabledColor = System.Drawing.Color.Gray;
            this.Executebtn.Iconcolor = System.Drawing.Color.Transparent;
            this.Executebtn.Iconimage = null;
            this.Executebtn.Iconimage_right = null;
            this.Executebtn.Iconimage_right_Selected = null;
            this.Executebtn.Iconimage_Selected = null;
            this.Executebtn.IconMarginLeft = 0;
            this.Executebtn.IconMarginRight = 0;
            this.Executebtn.IconRightVisible = true;
            this.Executebtn.IconRightZoom = 0D;
            this.Executebtn.IconVisible = true;
            this.Executebtn.IconZoom = 90D;
            this.Executebtn.IsTab = false;
            this.Executebtn.Location = new System.Drawing.Point(5, 317);
            this.Executebtn.Name = "Executebtn";
            this.Executebtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Executebtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.Executebtn.OnHoverTextColor = System.Drawing.Color.White;
            this.Executebtn.selected = false;
            this.Executebtn.Size = new System.Drawing.Size(98, 24);
            this.Executebtn.TabIndex = 40;
            this.Executebtn.Text = "EXECUTE";
            this.Executebtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Executebtn.Textcolor = System.Drawing.Color.WhiteSmoke;
            this.Executebtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Executebtn.Click += new System.EventHandler(this.Executebtn_Click);
            // 
            // Clearbtn
            // 
            this.Clearbtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.Clearbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Clearbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Clearbtn.BorderRadius = 0;
            this.Clearbtn.ButtonText = "CLEAR";
            this.Clearbtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.Clearbtn.DisabledColor = System.Drawing.Color.Gray;
            this.Clearbtn.Iconcolor = System.Drawing.Color.Transparent;
            this.Clearbtn.Iconimage = null;
            this.Clearbtn.Iconimage_right = null;
            this.Clearbtn.Iconimage_right_Selected = null;
            this.Clearbtn.Iconimage_Selected = null;
            this.Clearbtn.IconMarginLeft = 0;
            this.Clearbtn.IconMarginRight = 0;
            this.Clearbtn.IconRightVisible = true;
            this.Clearbtn.IconRightZoom = 0D;
            this.Clearbtn.IconVisible = true;
            this.Clearbtn.IconZoom = 90D;
            this.Clearbtn.IsTab = false;
            this.Clearbtn.Location = new System.Drawing.Point(108, 317);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Clearbtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.Clearbtn.OnHoverTextColor = System.Drawing.Color.White;
            this.Clearbtn.selected = false;
            this.Clearbtn.Size = new System.Drawing.Size(98, 24);
            this.Clearbtn.TabIndex = 39;
            this.Clearbtn.Text = "CLEAR";
            this.Clearbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Clearbtn.Textcolor = System.Drawing.Color.WhiteSmoke;
            this.Clearbtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // Openbtn
            // 
            this.Openbtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.Openbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Openbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Openbtn.BorderRadius = 0;
            this.Openbtn.ButtonText = "OPEN FILE";
            this.Openbtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.Openbtn.DisabledColor = System.Drawing.Color.Gray;
            this.Openbtn.Iconcolor = System.Drawing.Color.Transparent;
            this.Openbtn.Iconimage = null;
            this.Openbtn.Iconimage_right = null;
            this.Openbtn.Iconimage_right_Selected = null;
            this.Openbtn.Iconimage_Selected = null;
            this.Openbtn.IconMarginLeft = 0;
            this.Openbtn.IconMarginRight = 0;
            this.Openbtn.IconRightVisible = true;
            this.Openbtn.IconRightZoom = 0D;
            this.Openbtn.IconVisible = true;
            this.Openbtn.IconZoom = 90D;
            this.Openbtn.IsTab = false;
            this.Openbtn.Location = new System.Drawing.Point(211, 317);
            this.Openbtn.Name = "Openbtn";
            this.Openbtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Openbtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.Openbtn.OnHoverTextColor = System.Drawing.Color.White;
            this.Openbtn.selected = false;
            this.Openbtn.Size = new System.Drawing.Size(98, 24);
            this.Openbtn.TabIndex = 38;
            this.Openbtn.Text = "OPEN FILE";
            this.Openbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Openbtn.Textcolor = System.Drawing.Color.WhiteSmoke;
            this.Openbtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Openbtn.Click += new System.EventHandler(this.Openbtn_Click);
            // 
            // Savebtn
            // 
            this.Savebtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.Savebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Savebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Savebtn.BorderRadius = 0;
            this.Savebtn.ButtonText = "SAVE FILE";
            this.Savebtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.Savebtn.DisabledColor = System.Drawing.Color.Gray;
            this.Savebtn.Iconcolor = System.Drawing.Color.Transparent;
            this.Savebtn.Iconimage = null;
            this.Savebtn.Iconimage_right = null;
            this.Savebtn.Iconimage_right_Selected = null;
            this.Savebtn.Iconimage_Selected = null;
            this.Savebtn.IconMarginLeft = 0;
            this.Savebtn.IconMarginRight = 0;
            this.Savebtn.IconRightVisible = true;
            this.Savebtn.IconRightZoom = 0D;
            this.Savebtn.IconVisible = true;
            this.Savebtn.IconZoom = 90D;
            this.Savebtn.IsTab = false;
            this.Savebtn.Location = new System.Drawing.Point(314, 317);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Savebtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.Savebtn.OnHoverTextColor = System.Drawing.Color.White;
            this.Savebtn.selected = false;
            this.Savebtn.Size = new System.Drawing.Size(98, 24);
            this.Savebtn.TabIndex = 37;
            this.Savebtn.Text = "SAVE FILE";
            this.Savebtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Savebtn.Textcolor = System.Drawing.Color.WhiteSmoke;
            this.Savebtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // Injectbtn
            // 
            this.Injectbtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.Injectbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Injectbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Injectbtn.BorderRadius = 0;
            this.Injectbtn.ButtonText = "INJECT";
            this.Injectbtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.Injectbtn.DisabledColor = System.Drawing.Color.Gray;
            this.Injectbtn.Iconcolor = System.Drawing.Color.Transparent;
            this.Injectbtn.Iconimage = null;
            this.Injectbtn.Iconimage_right = null;
            this.Injectbtn.Iconimage_right_Selected = null;
            this.Injectbtn.Iconimage_Selected = null;
            this.Injectbtn.IconMarginLeft = 0;
            this.Injectbtn.IconMarginRight = 0;
            this.Injectbtn.IconRightVisible = true;
            this.Injectbtn.IconRightZoom = 0D;
            this.Injectbtn.IconVisible = true;
            this.Injectbtn.IconZoom = 90D;
            this.Injectbtn.IsTab = false;
            this.Injectbtn.Location = new System.Drawing.Point(417, 317);
            this.Injectbtn.Name = "Injectbtn";
            this.Injectbtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.Injectbtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.Injectbtn.OnHoverTextColor = System.Drawing.Color.White;
            this.Injectbtn.selected = false;
            this.Injectbtn.Size = new System.Drawing.Size(98, 24);
            this.Injectbtn.TabIndex = 36;
            this.Injectbtn.Text = "INJECT";
            this.Injectbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Injectbtn.Textcolor = System.Drawing.Color.WhiteSmoke;
            this.Injectbtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Injectbtn.Click += new System.EventHandler(this.Injectbtn_Click);
            // 
            // OptionsBtn
            // 
            this.OptionsBtn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.OptionsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.OptionsBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.OptionsBtn.BorderRadius = 0;
            this.OptionsBtn.ButtonText = "OPTIONS";
            this.OptionsBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.OptionsBtn.DisabledColor = System.Drawing.Color.Gray;
            this.OptionsBtn.Iconcolor = System.Drawing.Color.Transparent;
            this.OptionsBtn.Iconimage = null;
            this.OptionsBtn.Iconimage_right = null;
            this.OptionsBtn.Iconimage_right_Selected = null;
            this.OptionsBtn.Iconimage_Selected = null;
            this.OptionsBtn.IconMarginLeft = 0;
            this.OptionsBtn.IconMarginRight = 0;
            this.OptionsBtn.IconRightVisible = true;
            this.OptionsBtn.IconRightZoom = 0D;
            this.OptionsBtn.IconVisible = true;
            this.OptionsBtn.IconZoom = 90D;
            this.OptionsBtn.IsTab = false;
            this.OptionsBtn.Location = new System.Drawing.Point(577, 317);
            this.OptionsBtn.Name = "OptionsBtn";
            this.OptionsBtn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.OptionsBtn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.OptionsBtn.OnHoverTextColor = System.Drawing.Color.White;
            this.OptionsBtn.selected = false;
            this.OptionsBtn.Size = new System.Drawing.Size(98, 24);
            this.OptionsBtn.TabIndex = 41;
            this.OptionsBtn.Text = "OPTIONS";
            this.OptionsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.OptionsBtn.Textcolor = System.Drawing.Color.WhiteSmoke;
            this.OptionsBtn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OptionsBtn.Click += new System.EventHandler(this.OptionsBtn_Click);
            // 
            // krnlss
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.ClientSize = new System.Drawing.Size(679, 345);
            this.Controls.Add(this.OptionsBtn);
            this.Controls.Add(this.Executebtn);
            this.Controls.Add(this.Clearbtn);
            this.Controls.Add(this.Openbtn);
            this.Controls.Add(this.Savebtn);
            this.Controls.Add(this.Injectbtn);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.ExecuteBox);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listbox1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "krnlss";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KRNL";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.krnlss_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ExecuteBox)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TreeView listbox1;
        private FastColoredTextBoxNS.FastColoredTextBox ExecuteBox;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem injectToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem killRobloxToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem creditsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creditsToolStripMenuItem1;
        private ns1.BunifuFlatButton Injectbtn;
        private ns1.BunifuFlatButton Savebtn;
        private ns1.BunifuFlatButton Openbtn;
        private ns1.BunifuFlatButton Clearbtn;
        private ns1.BunifuFlatButton Executebtn;
        private Siticone.UI.WinForms.SiticoneDragControl siticoneDragControl1;
        private Siticone.UI.WinForms.SiticoneDragControl siticoneDragControl2;
        private ns1.BunifuFlatButton OptionsBtn;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem joinDiscordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gitHubToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem websiteToolStripMenuItem;
    }
}