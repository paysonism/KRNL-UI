PrettyBin
=========

Make bin folder of your project small, pretty and easy to maintain!

Moves dll,pdb and xml in bin/lib subfolder and ensures, that everything works.

Your bin folder will look like this:

/lib

app.exe

app.config
