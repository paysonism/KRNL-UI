param($installPath, $toolsPath, $package, $project)

Write-Host 'Init BinPrettify'